package pe.edu.upeu.parisfx.control;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import pe.edu.upeu.parisfx.dto.MenuMenuItenTO;
import pe.edu.upeu.parisfx.dto.SessionManager;
import pe.edu.upeu.parisfx.servicio.MenuMenuItemDao;
import pe.edu.upeu.parisfx.servicio.MenuMenuItenDaoI;
import pe.edu.upeu.parisfx.utils.UtilsX;

import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.prefs.Preferences;

@Component
public class GUIMainFX {

    @Autowired
    private ApplicationContext context;

    Preferences userPrefs = Preferences.userRoot();
    UtilsX util = new UtilsX();
    Properties myresources = new Properties();
    MenuMenuItenDaoI mmiDao;

    @FXML
    private TabPane tabPaneFx;
    private List<MenuMenuItenTO> lista;

    @FXML
    private BorderPane bp;

    @FXML
    private MenuBar menuBarFx;

    private Parent parent;
    private Stage stage;

    @FXML
    public void initialize() {
        Platform.runLater(() -> {
            stage = (Stage) tabPaneFx.getScene().getWindow();
            System.out.println("El título del stage es: " + stage.getTitle());
        });

        myresources = util.detectLanguage(userPrefs.get("IDIOMAX", "en"));
        mmiDao = new MenuMenuItemDao();
        String perfil = SessionManager.getInstance().getNombrePerfil();
        lista = mmiDao.listaAccesos(perfil, myresources);

        setupMenu();
    }

    private void setupMenu() {
        int[] mmi = contarMenuMunuItem(lista);
        Menu[] menu = new Menu[mmi[0]];
        MenuItem[] menuItem = new MenuItem[mmi[1]];

        menuBarFx = new MenuBar();
        MenuItemListener itemListener = new MenuItemListener();
        String menuN = "";
        int menui = 0, menuitem = 0;

        for (MenuMenuItenTO mmix : lista) {
            if (!mmix.menunombre.equals(menuN)) {
                menu[menui] = new Menu(mmix.menunombre);
                menu[menui].setId("m" + mmix.nombreObj);

                if (!mmix.menuitemnombre.equals("")) {
                    menuItem[menuitem] = createMenuItem(mmix, itemListener);
                    menu[menui].getItems().add(menuItem[menuitem]);
                    menuitem++;
                }
                menuBarFx.getMenus().add(menu[menui]);
                menuN = mmix.menunombre;
                menui++;
            } else if (!mmix.menuitemnombre.equals("")) {
                menuItem[menuitem] = createMenuItem(mmix, itemListener);
                menu[menui - 1].getItems().add(menuItem[menuitem]);
                menuitem++;
            }
        }

        // Layout principal
        bp.setTop(menuBarFx);
        bp.setCenter(tabPaneFx);
    }

    private MenuItem createMenuItem(MenuMenuItenTO mmix, MenuItemListener itemListener) {
        MenuItem menuItem = new MenuItem(mmix.menuitemnombre);
        menuItem.setId("mi" + mmix.nombreObj);
        menuItem.setOnAction(itemListener::handle);
        return menuItem;
    }

    public int[] contarMenuMunuItem(List<MenuMenuItenTO> data) {
        int menui = 0, menuitem = 0;
        String menuN = "";

        for (MenuMenuItenTO mmi : data) {
            if (!mmi.menunombre.equals(menuN)) {
                menuN = mmi.menunombre;
                menui++;
            }
            if (!mmi.menuitemnombre.equals("")) {
                menuitem++;
            }
        }
        return new int[]{menui, menuitem};
    }

    class MenuItemListener {
        public void handle(javafx.event.ActionEvent e) {
            MenuItem source = (MenuItem) e.getSource();
            tabPaneFx.getTabs().clear();

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(getFXMLPath(source.getId())));
                loader.setControllerFactory(context::getBean);
                Parent paneFromFXML = loader.load();
                ScrollPane scrollPane = new ScrollPane(paneFromFXML);
                Tab newTab = new Tab(getTabTitle(source.getId()), scrollPane);
                tabPaneFx.getTabs().add(newTab);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }

        private String getFXMLPath(String menuItemId) {
            switch (menuItemId) {
                case "mimiregproduct":
                    return "/view/main_producto.fxml";
                case "mimiautcomp":
                    return "/view/main_prod_autocomp.fxml";
                case "mimiAlmacen":
                    return "/view/almacen_paris.fxml";
                case "mimiproveedores":
                    return "/view/proveedores_paris.fxml";
                case "micrearcuenta":
                    return "/view/Crear_cuenta_paris.fxml";
                case "mimisalir":
                    return "/view/login_paris.fxml";
                default:
                    return null;
            }
        }

        private String getTabTitle(String menuItemId) {
            switch (menuItemId) {
                case "mimiregproduct":
                    return "Reg. Producto";
                case "mimiautcomp":
                    return "Form Autocomplete";
                case "mimiAlmacen":
                    return "Almacén de Productos";
                case "mimiproveedor":
                    return "Proveedor";
                case "micrearcuenta":
                    return "Crear Cuenta";
                case "mimisalir":
                    return "Salir";
                default:
                    return "";
            }
        }
    }
}
