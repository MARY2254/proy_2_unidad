package pe.edu.upeu.parisfx.control;

import jakarta.validation.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import pe.edu.upeu.parisfx.modelo.Proveedor;
import pe.edu.upeu.parisfx.servicio.ProveedorService;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Component
public class ProveedorController {
    @Autowired
    private ProveedorService proveedorService;

    @FXML
    private TextField txtDniRuc, txtNombresRaso, txtTipoDoc, txtCelular, txtEmail, txtDireccion;

    @FXML
    private TableView<Proveedor> tableViewProveedores;
    @FXML
    private TableColumn<Proveedor, String> colDniRuc;
    @FXML
    private TableColumn<Proveedor, String> colNombresRaso;
    @FXML
    private TableColumn<Proveedor, String> colTipoDoc;
    @FXML
    private TableColumn<Proveedor, String> colCelular;
    @FXML
    private TableColumn<Proveedor, String> colEmail;
    @FXML
    private TableColumn<Proveedor, String> colDireccion;
    @FXML
    private Label lbnMsg;
    @FXML
    private AnchorPane miproveedor;

    private Long idProveedorCE = 0L;
    private Validator validator;

    @FXML
    public void initialize() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
        loadProveedores();
        tableViewProveedores.setTableMenuButtonVisible(true);

        // Configurar columnas
        colDniRuc.setCellValueFactory(new PropertyValueFactory<>("dniRuc"));
        colNombresRaso.setCellValueFactory(new PropertyValueFactory<>("nombresRaso"));
        colTipoDoc.setCellValueFactory(new PropertyValueFactory<>("tipoDoc"));
        colCelular.setCellValueFactory(new PropertyValueFactory<>("celular"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colDireccion.setCellValueFactory(new PropertyValueFactory<>("direccion"));
    }

    private void loadProveedores() {
        List<Proveedor> proveedores = proveedorService.list();
        ObservableList<Proveedor> observableProveedores = FXCollections.observableArrayList(proveedores);
        tableViewProveedores.setItems(observableProveedores);
    }

    private boolean validateInputs() {
        Proveedor proveedor = new Proveedor();
        proveedor.setDniRuc(txtDniRuc.getText());
        proveedor.setNombresRaso(txtNombresRaso.getText());
        proveedor.setTipoDoc(txtTipoDoc.getText());
        proveedor.setCelular(txtCelular.getText());
        proveedor.setEmail(txtEmail.getText());
        proveedor.setDireccion(txtDireccion.getText());

        Set<ConstraintViolation<Proveedor>> violations = validator.validate(proveedor);
        if (!violations.isEmpty()) {
            displayValidationErrors(violations);
            return false;
        }
        return true;
    }

    private void displayValidationErrors(Set<ConstraintViolation<Proveedor>> violations) {
        StringBuilder sb = new StringBuilder("Errores: ");
        for (ConstraintViolation<Proveedor> violation : violations) {
            sb.append(violation.getMessage()).append("\n");
        }
        lbnMsg.setText(sb.toString());
        lbnMsg.setStyle("-fx-text-fill: red;");
    }

    @FXML
    private void handleSave() {
        if (!validateInputs()) {
            return; // Salir si hay errores de validación
        }

        Proveedor proveedor = new Proveedor();
        proveedor.setDniRuc(txtDniRuc.getText());
        proveedor.setNombresRaso(txtNombresRaso.getText());
        proveedor.setTipoDoc(txtTipoDoc.getText());
        proveedor.setCelular(txtCelular.getText());
        proveedor.setEmail(txtEmail.getText());
        proveedor.setDireccion(txtDireccion.getText());

        try {
            if (idProveedorCE != 0L) {
                proveedor.setIdProveedor(idProveedorCE);
                proveedorService.update(proveedor, idProveedorCE);
                lbnMsg.setText("Proveedor actualizado correctamente!");
            } else {
                proveedorService.save(proveedor);
                lbnMsg.setText("Proveedor guardado correctamente!");
            }
            lbnMsg.setStyle("-fx-text-fill: green;");
            clearFields();
            loadProveedores();
        } catch (Exception e) {
            lbnMsg.setText("Error al guardar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: red;");
        }
    }

    private void clearFields() {
        txtDniRuc.clear();
        txtNombresRaso.clear();
        txtTipoDoc.clear();
        txtCelular.clear();
        txtEmail.clear();
        txtDireccion.clear();
        idProveedorCE = 0L;
    }

    @FXML
    private void handleDelete() {
        Proveedor selectedProveedor = tableViewProveedores.getSelectionModel().getSelectedItem();
        if (selectedProveedor != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmar eliminación");
            alert.setHeaderText("Está a punto de eliminar un proveedor.");
            alert.setContentText("¿Está seguro de que desea continuar?");

            ButtonType buttonTypeCancel = new ButtonType("Cancelar");
            ButtonType buttonTypeOk = new ButtonType("Aceptar");
            alert.getButtonTypes().setAll(buttonTypeOk, buttonTypeCancel);

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == buttonTypeOk) {
                proveedorService.delete(selectedProveedor.getIdProveedor());
                loadProveedores();
                lbnMsg.setText("Proveedor eliminado correctamente!");
                lbnMsg.setStyle("-fx-text-fill: green;");
            }
        } else {
            lbnMsg.setText("Seleccione un proveedor para eliminar.");
            lbnMsg.setStyle("-fx-text-fill: red;");
        }
    }

    @FXML
    private void handleEdit() {
        Proveedor selectedProveedor = tableViewProveedores.getSelectionModel().getSelectedItem();
        if (selectedProveedor != null) {
            txtDniRuc.setText(selectedProveedor.getDniRuc());
            txtNombresRaso.setText(selectedProveedor.getNombresRaso());
            txtTipoDoc.setText(selectedProveedor.getTipoDoc());
            txtCelular.setText(selectedProveedor.getCelular());
            txtEmail.setText(selectedProveedor.getEmail());
            txtDireccion.setText(selectedProveedor.getDireccion());
            idProveedorCE = selectedProveedor.getIdProveedor();
        } else {
            lbnMsg.setText("Seleccione un proveedor para editar.");
            lbnMsg.setStyle("-fx-text-fill: red;");
        }
    }
}
