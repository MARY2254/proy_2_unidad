package pe.edu.upeu.parisfx;

public class Main {
    public static void main(String[] args) {
        ParisfxApplication.main(args);
    }
}
